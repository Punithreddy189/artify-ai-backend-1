# Placeholder for Firebase integration
def verify_token(token: str) -> bool:
    return True