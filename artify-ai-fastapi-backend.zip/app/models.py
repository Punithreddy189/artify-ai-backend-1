from pydantic import BaseModel

class ArtRequest(BaseModel):
    prompt: str
    style: str
    resolution: str