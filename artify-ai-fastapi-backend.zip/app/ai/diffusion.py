def generate_image(prompt: str, style: str, resolution: str) -> str:
    # This is a mock function. Replace with real Hugging Face inference.
    styled_prompt = f"{prompt} in {style} style"
    # Here you'd call a diffusion model like Stable Diffusion
    return f"https://dummyimage.com/{resolution.replace('x', '/')}?text={styled_prompt}"