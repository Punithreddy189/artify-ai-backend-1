from fastapi import APIRouter
from app.models import ArtRequest
from app.ai.diffusion import generate_image

router = APIRouter()

@router.post("/generate")
async def generate_art(request: ArtRequest):
    image_url = generate_image(request.prompt, request.style, request.resolution)
    return {"stylizedImageUrl": image_url}