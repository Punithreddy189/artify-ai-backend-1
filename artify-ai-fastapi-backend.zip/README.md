# Artify AI FastAPI Backend

## Features
- Modular FastAPI backend for AI Art generation
- CORS enabled
- Endpoint: `/api/art/generate`
- Swagger UI at `/docs`

## Run locally
```
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Docker
```
docker build -t artify-backend .
docker run -p 8000:8000 artify-backend
```