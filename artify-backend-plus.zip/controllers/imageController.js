const fs = require('fs');
const path = require('path');
const axios = require('axios');

exports.styleTransfer = async (req, res) => {
  try {
    const imagePath = path.join(__dirname, `../uploads/${req.file.filename}`);
    const imageData = fs.readFileSync(imagePath, { encoding: 'base64' });

    const response = await axios.post(
      'https://api.replicate.com/v1/predictions',
      {
        version: "your-model-version-id",
        input: {
          image: `data:image/jpeg;base64,${imageData}`
        }
      },
      {
        headers: {
          Authorization: `Token ${process.env.REPLICATE_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    fs.unlinkSync(imagePath); // clean up local file
    res.json(response.data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to process image' });
  }
};
